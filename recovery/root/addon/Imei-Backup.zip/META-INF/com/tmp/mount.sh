#!/sbin/sh
mount -o rw /system_root
rm -rf /sdcard/imeibackup /sdcard/imeibackup.zip /sdcard/Flashable-IMEI-Backup*.zip /sdcard/Imei-Restore-By-@shas45558.zip
cd addon
mkdir imeibackup
cd imeibackup
mkdir META-INF
cd META-INF
mkdir com
cd com
mkdir google
cd google 
mkdir android 
cp /addon/update-binary /addon/imeibackup/META-INF/com/google/android

dd if=/dev/block/platform/bootdevice/by-name/nvcfg of=/addon/imeibackup/nvcfg.img

dd if=/dev/block/platform/bootdevice/by-name/nvdata of=/addon/imeibackup/nvdata.img

dd if=/dev/block/platform/bootdevice/by-name/persist of=/addon/imeibackup/persist.img

dd if=/dev/block/platform/bootdevice/by-name/protect1 of=/addon/imeibackup/protect1.img

dd if=/dev/block/platform/bootdevice/by-name/protect2 of=/addon/imeibackup/protect2.img


dd if=/dev/block/platform/bootdevice/by-name/seccfg of=/addon/imeibackup/seccfg.bin

dd if=/dev/block/platform/bootdevice/by-name/nvram of=/addon/imeibackup/nvram.bin

cd /addon/imeibackup

touch /META-INF/com/google/android/updater-script

echo 'ui_print (" ");
ui_print (" ");
ui_print (" IMEI Restore Script(via Recovery) for Lancelot, Merlin, Shiva by @shas45558");
ui_print (" ");
ui_print (" ");
ui_print (" Flashing nvram, nvdata, nvcfg, persist, protect1, protect2 , seccfg.... ");
ui_print (" ");
ui_print (" ");

package_extract_file("nvram.bin", "/dev/block/by-name/nvram");
package_extract_file("nvdata.img", "/dev/block/by-name/nvdata");
package_extract_file("persist.img", "/dev/block/by-name/persist");
package_extract_file("protect1.img", "/dev/block/by-name/protect1");
package_extract_file("protect2.img", "/dev/block/by-name/protect2");
package_extract_file("nvcfg.img", "/dev/block/by-name/nvcfg");
package_extract_file("seccfg.bin", "/dev/block/by-name/seccfg");

ui_print (" Flashed All Partitions! ");
ui_print (" ");
ui_print (" ");
ui_print (" IMEI Should Hopefully Be Restored");
ui_print (" ");
ui_print (" ");
' >> /addon/imeibackup/META-INF/com/google/android/updater-script

zip -r Imei-Restore-By-@shas45558 *

cp /addon/imeibackup/Imei-Restore-By-@shas45558.zip /sdcard
